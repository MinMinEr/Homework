//
//  searchFriendVC.h
//  XMLL2
//
//  Created by zzddn on 2017/2/5.
//  Copyright © 2017年 zzddn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface searchFriendVC : UIViewController

@end
