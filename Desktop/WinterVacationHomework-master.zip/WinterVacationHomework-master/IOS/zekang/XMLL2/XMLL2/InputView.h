//
//  InputView.h
//  XMLL2
//
//  Created by zzddn on 2017/1/29.
//  Copyright © 2017年 zzddn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InputView : UIView
@property (nonatomic,strong)UITextView *inputTextView;

@end
